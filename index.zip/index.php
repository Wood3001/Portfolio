<?php

require('db/init.php');

// Redirect users to the public site
redirect('/');

// Sherwood Seabrook A00740466
// Portfolio 2